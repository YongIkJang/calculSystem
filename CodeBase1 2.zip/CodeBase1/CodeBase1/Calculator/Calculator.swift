//
//  Calculator.swift
//  CodeBase1
//
//  Created by 김나훈 on 11/5/24.
//

import Foundation

struct Calculator {
    // 현재 입력 값과 이전 값 저장
    private(set) var currentInput: Double = 0
    private var previousInput: Double = 0
    private var currentOperation: Operation = .addition

    // 연산 타입 정의
    enum Operation {
        case addition
    }
    
    // 입력 초기화
    mutating func setInput(_ input: Double) {
        currentInput = input
    }
    
    // 연산 설정
    mutating func setOperation(_ operation: Operation) {
        previousInput = currentInput
        currentInput = 0
        currentOperation = operation
    }
    
    // 결과 계산
    mutating func calculate() -> Double {
      
        let result: Double

        switch currentOperation {
        case .addition:
            result = previousInput + currentInput
        }
        
        currentInput = result
        return result
    }
}
