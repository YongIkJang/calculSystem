//
//  ViewController.swift
//  CodeBase1
//
//  Created by 김나훈 on 10/29/24.
//

import UIKit


//class ViewController: UIViewController {
//    
//    // MARK: - Properties
//    
//    private var calculator = Calculator()
//    
//    // UI Components
//    private let displayLabel: UILabel = {
//        let label = UILabel()
//        label.text = "0"
//        label.translatesAutoresizingMaskIntoConstraints = false
//        return label
//    }()
//    
//    private let inputTextField1: UITextField = {
//        let textField = UITextField()
//        textField.placeholder = "Enter first number"
//        textField.translatesAutoresizingMaskIntoConstraints = false
//        return textField
//    }()
//    
//    private let inputTextField2: UITextField = {
//        let textField = UITextField()
//        textField.placeholder = "Enter second number"
//        textField.translatesAutoresizingMaskIntoConstraints = false
//        return textField
//    }()
//    
//    // Operation Buttons
//    private let addButton: UIButton = {
//        let button = UIButton(type: .system)
//        button.setTitle("+", for: .normal)
//        button.translatesAutoresizingMaskIntoConstraints = false
//        return button
//    }()
//    
//    private let calculateButton: UIButton = {
//        let button = UIButton(type: .system)
//        button.setTitle("Calculate", for: .normal)
//        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 24)
//        button.translatesAutoresizingMaskIntoConstraints = false
//        return button
//    }()
//    
//    // MARK: - Lifecycle
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        setupViews()
//        addButton.addTarget(self, action: #selector(addButtonTapped), for: .touchUpInside)
//        calculateButton.addTarget(self, action: #selector(calculateResult), for: .touchUpInside)
//    }
//    
//    // MARK: - Setup Views
//    
//    private func setupViews() {
//        view.backgroundColor = .white
//        view.addSubview(displayLabel)
//        view.addSubview(inputTextField1)
//        view.addSubview(inputTextField2)
//        view.addSubview(addButton)
//        view.addSubview(calculateButton)
//        
//        // Constraints
//        NSLayoutConstraint.activate([
//            displayLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 40),
//            displayLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
//            displayLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
//            
//            inputTextField1.topAnchor.constraint(equalTo: displayLabel.bottomAnchor, constant: 20),
//            inputTextField1.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
//            inputTextField1.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
//            
//            inputTextField2.topAnchor.constraint(equalTo: inputTextField1.bottomAnchor, constant: 10),
//            inputTextField2.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
//            inputTextField2.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
//            
//            addButton.topAnchor.constraint(equalTo: inputTextField2.bottomAnchor, constant: 20),
//            addButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
//            
//            calculateButton.topAnchor.constraint(equalTo: addButton.bottomAnchor, constant: 20),
//            calculateButton.centerXAnchor.constraint(equalTo: view.centerXAnchor)
//        ])
//    }
//    
//    
//    // MARK: - Actions
//    
//    @objc private func addButtonTapped(_ sender: UIButton) {
//        guard let text1 = inputTextField1.text, let value1 = Double(text1) else { return }
//        guard let text2 = inputTextField2.text, let value2 = Double(text2) else { return }
//        
//        // 모델에 입력값 설정
//        calculator.setInput(value1)
//        
//        // 연산 설정
//        calculator.setOperation(.addition)
//        
//        
//        calculator.setInput(value2)
//    }
//    
//    @objc private func calculateResult() {
//        let result = calculator.calculate()
//        displayLabel.text = "Result: \(result)"
//        
//    }
//}

