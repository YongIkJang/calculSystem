//
//  User.swift
//  CodeBase1
//
//  Created by 김나훈 on 11/5/24.
//

import Foundation

struct User {
    var name: String
}
