//
//  Sample.swift
//  CodeBase1
//
//  Created by 김나훈 on 11/5/24.
//

import UIKit

class ViewController: UIViewController {
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
