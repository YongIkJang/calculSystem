//
//  ViewController.swift
//  Practice1
//
//  Created by 김나훈 on 10/8/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var incrementButton: UIButton!
    @IBOutlet weak var imageView: UIImageView!
    let randomImageValues: [String] = ["pencil", "eraser", ""]
    
    private var num: Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        countLabel.text = String(num)
        imageView.image = UIImage(systemName: "pencil")
    }

    @IBAction func incrementButtonTapped(_ sender: Any) {
        num += 1
        countLabel.text = String(num)
  //      print(randomElements.randomElement())
        // 1. 어떻게 옵셔널 언래핑 할것인지.
        // 2. 어떻게 UIImage 배열중 랜덤한 값을 얻을것인지
    }
    @IBAction func decrementButtonTapped(_ sender: Any) {
        num -= 1
        countLabel.text = String(num)
    }
    
}

