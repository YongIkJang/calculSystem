    //
    //  ViewController.swift
    //  homew1104
    //
    //  Created by yongik on 11/4/24.
    //

    import UIKit

    class ViewController: UIViewController {
        let resultLabel = UILabel() // 라벨을 만들어 주고
        override func viewDidLoad() {
                super.viewDidLoad()
                
                //변수 설정
            
            
                // 결과 표시 레이블
                resultLabel.text = "0" // text가 무엇인지 설정
                resultLabel.textColor = .white
                resultLabel.textAlignment = .right // 오른쪽으로 글자 설정
                resultLabel.translatesAutoresizingMaskIntoConstraints = false //오토 레이아웃을 사용하기 위해서
                view.addSubview(resultLabel) // 결과 label을 뷰에 추가
                
                NSLayoutConstraint.activate([ // 결과 label 오토레이아웃 설정
                    resultLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
                    resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
                    resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
                    resultLabel.heightAnchor.constraint(equalToConstant: 80)
                ])
                
                // 버튼 배열 설정
                let buttonTitles = [
                    ["7", "8", "9", "÷"],
                    ["4", "5", "6", "*"],
                    ["1", "2", "3", "-"],
                    ["0", ".", "=", "+"]
                ]
                
                let buttonStackView = UIStackView() // 스택 뷰를 만들고
                buttonStackView.axis = .vertical //수직 vs 수평 (horizontal)
                buttonStackView.distribution = .fillEqually // 꽉 채우기 (동등하게)
                buttonStackView.spacing = 10 // spacing 거리 설정
                buttonStackView.translatesAutoresizingMaskIntoConstraints = false //오토 레이아웃 설정
                view.addSubview(buttonStackView)
                
                // 버튼 행을 StackView에 추가
                for row in buttonTitles { //2차원 배열의 바깥쪽
                    let rowStackView = UIStackView()
                    rowStackView.axis = .horizontal
                    rowStackView.distribution = .fillEqually
                    rowStackView.spacing = 10
                    
                    for title in row {
                        let button = UIButton(type: .system)
                        button.setTitle(title, for: .normal)
                        button.titleLabel?.font = UIFont.systemFont(ofSize: 24)
                        if title != "="{
                            button.addTarget(self, action: #selector(buttonTapped(_:)), for: .touchUpInside)
                        }
                        else {
                            button.addTarget(self, action:#selector(intTapped(_:)),for: . touchUpInside)
                        }
                        rowStackView.addArrangedSubview(button)
                    }
                    
                    buttonStackView.addArrangedSubview(rowStackView)
                }
                
                // 오토레이아웃 설정
                NSLayoutConstraint.activate([
                    buttonStackView.topAnchor.constraint(equalTo: resultLabel.bottomAnchor, constant: 20),
                    buttonStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
                    buttonStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
                    buttonStackView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
                ])
            }
            @objc func buttonTapped(_ sender: UIButton) {
                if let title = sender.currentTitle {
                    if resultLabel.text == "0" {
                        resultLabel.text = title
                    }
                    else{
                        resultLabel.text! += title
                    }
                }
            }
        @objc func intTapped(_ sender: UIButton) {
            let calculText: [String] = ["÷", "*", "-", "+"]
            var firstNum: Int = 0
            var secondNum: Int = 0
            var result: Int = 0
            var calcul: String = ""
            
            // 현재 resultLabel의 텍스트에서 각 연산자 기호에 따라 분리
            for compo in calculText {
                let resultcompo = resultLabel.text!.components(separatedBy: compo)
                
                // 연산자가 포함된 경우
                if resultcompo.count == 2,
                   let num1 = Int(resultcompo[0]), // 옵셔널 바인딩으로 Int 변환
                   let num2 = Int(resultcompo[1]) {
                    firstNum = num1
                    secondNum = num2
                    calcul = compo
                    break
                }
            }
            
            // 연산을 수행
            switch calcul {
            case "÷":
                result = secondNum != 0 ? firstNum / secondNum : 0 // 0으로 나누기 방지
            case "*":
                result = firstNum * secondNum
            case "-":
                result = firstNum - secondNum
            case "+":
                result = firstNum + secondNum
            default:
                break
            }
            
            // 결과 표시
            resultLabel.text = String(result)
        }
    }

