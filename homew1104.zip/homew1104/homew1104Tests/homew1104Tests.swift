//
//  homew1104Tests.swift
//  homew1104Tests
//
//  Created by yongik on 11/4/24.
//

import Testing
@testable import homew1104

struct homew1104Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
